def calculate_assessment(m):
    score=0; reasons=[]
    checks=[(m['total_events']>0,20,'Security-event data is available.'),(m['total_alerts']>0,20,'Detection rules generated alerts.'),(m['total_incidents']>0,20,'Incident workflow is being used.'),(m['resolved_incidents']>0,20,'At least one incident has been resolved.'),(m['total_alerts']>m['open_alerts'],10,'Some alerts moved beyond Open.'),(m['total_alerts']>=0,10,'Detection-time measurement is available.')]
    for ok,n,r in checks:
        if ok: score+=n; reasons.append(r)
    level='Strong prototype performance' if score>=80 else 'Good prototype performance' if score>=60 else 'Developing prototype' if score>=40 else 'Initial prototype stage'
    return {'score':score,'level':level,'reasons':reasons}
