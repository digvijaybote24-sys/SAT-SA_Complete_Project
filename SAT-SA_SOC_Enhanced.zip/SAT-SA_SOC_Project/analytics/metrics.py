from datetime import datetime
def dt(x):
    try:return datetime.fromisoformat(x.replace('Z','+00:00'))
    except:return None
def calculate_metrics(events,alerts,incidents):
    em={e['id']:e for e in events}; ds=[]; rs=[]
    for a in alerts:
        e=em.get(a['event_id']); x=dt(e['timestamp']) if e else None; y=dt(a['created_at'])
        if x and y and 0<=(y-x).total_seconds()<100000*60: ds.append((y-x).total_seconds()/60)
    for i in incidents:
        x=dt(i['opened_at']); y=dt(i['resolved_at']) if i['resolved_at'] else None
        if x and y: rs.append((y-x).total_seconds()/60)
    return {'total_events':len(events),'total_alerts':len(alerts),'open_alerts':sum(a['status']=='Open' for a in alerts),'total_incidents':len(incidents),'resolved_incidents':sum(i['status']=='Resolved' for i in incidents),'mttd_minutes':round(sum(ds)/len(ds),2) if ds else 0,'mttr_minutes':round(sum(rs)/len(rs),2) if rs else 0,'alert_rate':round(len(alerts)/len(events)*100,2) if events else 0,'resolution_rate':round(sum(i['status']=='Resolved' for i in incidents)/len(incidents)*100,2) if incidents else 0}
