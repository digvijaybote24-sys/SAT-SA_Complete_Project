from collections import defaultdict
def sev(s): return 'Critical' if s>=80 else 'High' if s>=60 else 'Medium' if s>=35 else 'Low'
def detect_events(events):
    out=[]; by=defaultdict(list)
    for e in events:
        if e['event_type'].lower() in {'login','authentication'} and e['action'].lower() in {'failed','failure','denied'}: by[e['source_ip']].append(e)
    for ip,items in by.items():
        if len(items)>=3:
            score=min(95,55+(len(items)-3)*8)
            for e in items: out.append({'event_id':e['id'],'rule_id':'AUTH-001','rule_name':'Possible Brute-Force Authentication','severity':sev(score),'score':score,'reason':f'{len(items)} failed authentication events observed from {ip}.'})
    for e in events:
        t=(e['message']+' '+e['event_type']+' '+e['action']).lower()
        if 'port scan' in t or 'nmap' in t or e['event_type'].lower() in {'port_scan','scan'}: out.append({'event_id':e['id'],'rule_id':'NET-001','rule_name':'Possible Port Scan','severity':'High','score':78,'reason':'Configured port-scanning indicator matched.'})
        if 'powershell' in t and any(x in t for x in ['encoded','bypass','downloadstring','hidden']): out.append({'event_id':e['id'],'rule_id':'END-001','rule_name':'Suspicious PowerShell Activity','severity':'High','score':82,'reason':'PowerShell activity matched a suspicious command indicator.'})
        for x in ['trojan','ransomware','malware','c2 beacon','command and control']:
            if x in t: out.append({'event_id':e['id'],'rule_id':'MAL-001','rule_name':'Malware Indicator Detected','severity':'Critical','score':92,'reason':f'Configured malware indicator matched: {x}.'}); break
    return list({(d['event_id'],d['rule_id']):d for d in out}.values())
