import csv,io
REQUIRED={'timestamp','source_ip','destination_ip','username','event_type','action','message'}
def parse_csv_text(text):
    r=csv.DictReader(io.StringIO(text))
    if not r.fieldnames: raise ValueError('CSV has no header row')
    missing=REQUIRED-set(r.fieldnames)
    if missing: raise ValueError('Missing columns: '+', '.join(sorted(missing)))
    out=[]
    for row in r:
        e={k:(row.get(k) or '').strip() for k in REQUIRED}
        if e['timestamp']: e['raw']=str(row); out.append(e)
    return out
