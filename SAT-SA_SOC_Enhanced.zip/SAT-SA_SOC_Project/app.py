from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from pathlib import Path
from datetime import datetime, timezone
import sqlite3, os
from detection.log_parser import parse_csv_text
from detection.detection_engine import detect_events
from analytics.metrics import calculate_metrics
from analytics.assessment import calculate_assessment
from analytics.supervision import analyze_supervision
from reports.report_generator import generate_report

BASE_DIR=Path(__file__).resolve().parent
DB_PATH=BASE_DIR/'database'/'soc.db'
DB_PATH.parent.mkdir(exist_ok=True)
app=Flask(__name__)
app.secret_key=os.environ.get('SAT_SA_SECRET_KEY','sat-sa-demo-change-this')

def db():
    c=sqlite3.connect(DB_PATH); c.row_factory=sqlite3.Row; return c

def init_db():
    c=db(); c.executescript('''
    CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT,timestamp TEXT,source_ip TEXT,destination_ip TEXT,username TEXT,event_type TEXT,action TEXT,message TEXT,raw TEXT,created_at TEXT);
    CREATE TABLE IF NOT EXISTS alerts(id INTEGER PRIMARY KEY AUTOINCREMENT,event_id INTEGER,rule_id TEXT,rule_name TEXT,severity TEXT,score INTEGER,reason TEXT,status TEXT DEFAULT 'Open',created_at TEXT,closed_at TEXT);
    CREATE TABLE IF NOT EXISTS incidents(id INTEGER PRIMARY KEY AUTOINCREMENT,alert_id INTEGER,title TEXT,severity TEXT,status TEXT DEFAULT 'Open',analyst TEXT,notes TEXT,opened_at TEXT,resolved_at TEXT);
    ''');
    cols={r['name'] for r in c.execute('PRAGMA table_info(alerts)').fetchall()}
    if 'closed_at' not in cols: c.execute('ALTER TABLE alerts ADD COLUMN closed_at TEXT')
    c.commit(); c.close()

def ingest(text):
    c=db(); events=parse_csv_text(text); now=datetime.now(timezone.utc).isoformat(); inserted=[]
    for e in events:
        cur=c.execute('INSERT INTO events(timestamp,source_ip,destination_ip,username,event_type,action,message,raw,created_at) VALUES(?,?,?,?,?,?,?,?,?)', (e['timestamp'],e['source_ip'],e['destination_ip'],e['username'],e['event_type'],e['action'],e['message'],e['raw'],now)); inserted.append({**e,'id':cur.lastrowid})
    detections=detect_events(inserted)
    for d in detections:
        c.execute('INSERT INTO alerts(event_id,rule_id,rule_name,severity,score,reason,status,created_at) VALUES(?,?,?,?,?,?,?,?)',(d['event_id'],d['rule_id'],d['rule_name'],d['severity'],d['score'],d['reason'],'Open',now))
    c.commit(); c.close(); return len(events),len(detections)

def seed():
    c=db()
    if c.execute('SELECT COUNT(*) FROM events').fetchone()[0]: c.close(); return
    p=BASE_DIR/'data'/'sample_logs.csv'
    c.close(); ingest(p.read_text(encoding='utf-8'))

@app.route('/')
def dashboard():
    c=db(); stats={k:c.execute(q).fetchone()[0] for k,q in {'events':'SELECT COUNT(*) FROM events','alerts':'SELECT COUNT(*) FROM alerts','open_alerts':"SELECT COUNT(*) FROM alerts WHERE status='Open'",'incidents':'SELECT COUNT(*) FROM incidents','open_incidents':"SELECT COUNT(*) FROM incidents WHERE status!='Resolved'"}.items()}; alerts=c.execute('SELECT a.*,e.timestamp,e.source_ip,e.username,e.event_type FROM alerts a LEFT JOIN events e ON e.id=a.event_id ORDER BY a.id DESC LIMIT 8').fetchall(); c.close(); return render_template('dashboard.html',stats=stats,alerts=alerts)

@app.route('/logs')
def logs():
    c=db(); rows=c.execute('SELECT * FROM events ORDER BY id DESC LIMIT 200').fetchall(); c.close(); return render_template('logs.html',rows=rows)

@app.route('/upload',methods=['GET','POST'])
def upload():
    if request.method=='POST':
        f=request.files.get('logfile')
        if not f: flash('Select a CSV file.','danger'); return redirect(url_for('upload'))
        try:
            n,a=ingest(f.read().decode('utf-8-sig')); flash(f'Imported {n} events and generated {a} alerts.','success')
        except Exception as e: flash(f'Import failed: {e}','danger')
        return redirect(url_for('dashboard'))
    return render_template('upload.html')

@app.route('/alerts')
def alerts():
    c=db(); rows=c.execute('SELECT a.*,e.timestamp,e.source_ip,e.destination_ip,e.username,e.event_type,e.message FROM alerts a LEFT JOIN events e ON e.id=a.event_id ORDER BY a.id DESC').fetchall(); c.close(); return render_template('alerts.html',rows=rows)

@app.post('/alerts/<int:alert_id>/status')
def alert_status(alert_id):
    s=request.form.get('status','Open'); s=s if s in {'Open','Investigating','Closed'} else 'Open'; c=db(); closed_at=datetime.now(timezone.utc).isoformat() if s=='Closed' else None; c.execute('UPDATE alerts SET status=?,closed_at=? WHERE id=?',(s,closed_at,alert_id)); c.commit(); c.close(); return redirect(url_for('alerts'))

@app.route('/incidents')
def incidents():
    c=db(); rows=c.execute('SELECT i.*,a.rule_name,a.score,a.reason FROM incidents i LEFT JOIN alerts a ON a.id=i.alert_id ORDER BY i.id DESC').fetchall(); c.close(); return render_template('incidents.html',rows=rows)

@app.post('/incidents/create/<int:alert_id>')
def create_incident(alert_id):
    c=db(); a=c.execute('SELECT * FROM alerts WHERE id=?',(alert_id,)).fetchone()
    if not a: c.close(); flash('Alert not found.','danger'); return redirect(url_for('alerts'))
    now=datetime.now(timezone.utc).isoformat(); c.execute('INSERT INTO incidents(alert_id,title,severity,status,analyst,notes,opened_at) VALUES(?,?,?,?,?,?,?)',(alert_id,f"{a['rule_name']} - Alert #{alert_id}",a['severity'],'Open','Student Analyst','',now)); c.execute("UPDATE alerts SET status='Investigating' WHERE id=?",(alert_id,)); c.commit(); c.close(); return redirect(url_for('incidents'))

@app.post('/incidents/<int:incident_id>/resolve')
def resolve_incident(incident_id):
    c=db(); i=c.execute('SELECT alert_id FROM incidents WHERE id=?',(incident_id,)).fetchone(); now=datetime.now(timezone.utc).isoformat()
    if i: c.execute('UPDATE incidents SET status=\'Resolved\',resolved_at=? WHERE id=?',(now,incident_id)); c.execute("UPDATE alerts SET status='Closed',closed_at=? WHERE id=?",(now,i['alert_id']))
    c.commit(); c.close(); return redirect(url_for('incidents'))

@app.route('/analytics')
def analytics():
    c=db(); ev=c.execute('SELECT * FROM events').fetchall(); al=c.execute('SELECT * FROM alerts').fetchall(); inc=c.execute('SELECT * FROM incidents').fetchall(); m=calculate_metrics(ev,al,inc); a=calculate_assessment(m); sup=analyze_supervision(ev,al,inc); c.close(); return render_template('analytics.html',metrics=m,assessment=a,supervision=sup)

@app.route('/report')
def report():
    c=db(); ev=c.execute('SELECT * FROM events').fetchall(); al=c.execute('SELECT * FROM alerts').fetchall(); inc=c.execute('SELECT * FROM incidents').fetchall(); m=calculate_metrics(ev,al,inc); a=calculate_assessment(m); sup=analyze_supervision(ev,al,inc); html=generate_report(m,a,al,sup); c.close(); return render_template('report.html',report_html=html)

@app.get('/api/stats')
def api_stats():
    c=db(); x={'events':c.execute('SELECT COUNT(*) FROM events').fetchone()[0],'alerts':c.execute('SELECT COUNT(*) FROM alerts').fetchone()[0],'incidents':c.execute('SELECT COUNT(*) FROM incidents').fetchone()[0]}; c.close(); return jsonify(x)

@app.post('/reset-demo')
def reset_demo():
    c=db(); c.executescript('DELETE FROM incidents;DELETE FROM alerts;DELETE FROM events;'); c.commit(); c.close(); seed(); return redirect(url_for('dashboard'))

if __name__=='__main__': init_db(); seed(); app.run(debug=True)
